const audio = document.getElementById('audio');
const title = document.getElementById('title');
const progress = document.getElementById('progress');

let tracks = ['song1.mp3', 'song2.mp3', 'song3.mp3', 'song4.mp3'];
let currentTrack = 0;

function loadTrack(index) {
  audio.src = tracks[index];
  title.innerText = `Now Playing: ${tracks[index]}`;
  audio.load();
}

function playPause() {
  if (audio.paused) audio.play();
  else audio.pause();
}

function nextSong() {
  currentTrack = (currentTrack + 1) % tracks.length;
  loadTrack(currentTrack);
  audio.play();
}

function prevSong() {
  currentTrack = (currentTrack - 1 + tracks.length) % tracks.length;
  loadTrack(currentTrack);
  audio.play();
}

function seekTrack(input) {
  audio.currentTime = audio.duration * (input.value / 100);
}

audio.addEventListener('timeupdate', () => {
  progress.value = (audio.currentTime / audio.duration) * 100;
});

loadTrack(currentTrack);
